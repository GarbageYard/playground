import sqlite3
sqlite3.sqlite_version